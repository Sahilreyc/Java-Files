 package vmtranslator;

 import java.io.IOException;
 import java.io.Writer;
 import java.util.Random;

/**
 * Output Hack ASM for VM code.
 *
 * @author djb
 */
public class CodeWriter {
    // Temporary registers for intermediate calculations,
    // should they be required by the translator.
    private static final String R13 = "R13", R14 = "R14", R15 = "R15";

    // Where the translation is written.
    private final Writer writer;
    // Current file being processed.
    private String currentFilename;

    /**
     * Create a CodeWriter to output to the given file.
     * @param writer Where to write the code.
     */
    public CodeWriter(Writer writer)
    {
        this.writer = writer;
    }

    /**
     * Translation of a new file.
     * @param filename The input file name.
     */
    public void setFilename(String filename)
    {
        this.currentFilename = filename;
    }

    /**
     * Translate the given arithmetic command.
     * @param command The command to be translated.
     * @throws java.io.IOException
     */
    public void writeArithmetic(String command)
            throws IOException
    {
        switch(command) {
            // Binary arithmetic operators.
            case "add":
              add();
              break;
            case "and":
              and();
              break;
            case "or":
              or();
              break;
            case "sub":
              sub();
              break;

            // Unary operators.
            case "neg":
              neg();
              break;
            case "not":
              not();
              break;

            // Relational operators.
            case "eq":
              eq();
              break;
            case "lt":
              lt();
              break;
            case "gt":
              gt();
              break;
            default:
                throw new IllegalStateException("Unrecognised arithmetic command: " + command);
        }
    }

    /**
     * Translate the given push or pop command.
     * @param command The command to be translated.
     * @param segment The segment to be accessed.
     * @param index   The index within segment.
     * @throws java.io.IOException
     */
    public void writePushPop(CommandType command, String segment, int index)
            throws IOException
    {
        if(null == command) {
            throw new IllegalStateException("Invalid command in writePushPop: " +
                    command);
        }
        else {
            switch (command) {
                case C_PUSH:
                    pushSegment(segment, index);
                    break;
                case C_POP:
                    popSegment(segment, index);
                    break;
                default:
                    throw new IllegalStateException("Invalid command in writePushPop: " +
                            command);
            }
        }
    }

    public void pushSegment(String segment, int index) throws IOException
    {
      if (segment == null)
      {
        throw new IllegalStateException("Invalid command in writePushPop: " + segment);
      }
      else {
        if (segment.equals("constant"))
        {
          pushConstant(index);
        }
        if (segment.equals("local"))
        {
          pushLocal(index);
        }
        if (segment.equals("argument"))
        {
          pushArgument(index);
        }
        if (segment.equals("this"))
        {
          pushThis(index);
        }
        if (segment.equals("that"))
        {
          pushThat(index);
        }
        if (segment.equals("temp"))
        {
          pushTemp(index);
        }
        if (segment.equals("pointer"))
        {
          pushPointer(index);
        }
        if (segment.equals("static"))
        {
          pushStatic(index);
        }



      }
    }

    public void popSegment(String segment, int index) throws IOException
    {
      if (segment == null)
      {
        throw new IllegalStateException("Invalid command in writePushPop: " + segment);
      }
      else {
        if (segment.equals("local"))
        {
          popLocal(index);
        }
        if (segment.equals("argument"))
        {
          popArgument(index);
        }
        if (segment.equals("this"))
        {
          popThis(index);
        }
        if (segment.equals("that"))
        {
          popThat(index);
        }
        if (segment.equals("temp"))
        {
          popTemp(index);
        }
        if (segment.equals("pointer"))
        {
          popPointer(index);
        }
        if (segment.equals("static"))
        {
          popStatic(index);
        }

      }
    }






    /**
     * Write the given text as a comment.
     * @param text the text to output.
     * @throws IOException
     */
    public void writeComment(String text)
            throws IOException
    {
        output("// " + text);
    }

    /**
     * Close the output file.
     * @throws IOException
     */
    public void close()
            throws IOException
    {
        try (writer) {
            String endOfProgram = "THATS_ALL_FOLKS";
            output("@" + endOfProgram);
            output(String.format("(%s)", endOfProgram));
            output("0;JMP");
        }
    }

    /**
     * Output the given string with an indent and
     * terminate the current line.
     * @param s The string to output.
     * @throws IOException
     */
    private void output(String s)
            throws IOException
    {
        writer.write("    ");
        writer.write(s);
        writer.write('\n');
    }

  //  public void setup() throws IOException{
//      output("@256");
//      output("D = A");
//      output("@SP");
//      output("M = D");

//      output("@300");
//      output("D = A");
//      output("@LCL");
  //    output("M = D");

//      output("@400");
  //    output("D = A");
    //  output("@ARG");
//      output("M = D");

//      output("@3000");
//      output("D = A");
//      output("@THIS");
//      output("M = D");

//      output("@3010");
//      output("D = A");
//      output("@THAT");
//      output("M = D");

//      output("@3");
//      output("D = A");
//      output("@PTR");
//      output("M = D");

//    }

    public void pushD() throws IOException
    {
        output("@SP");
        output("A = M");
        output("M = D");
        output("@SP");
        output("M = M + 1");
    }


    public void popD() throws IOException
    {
      output("@SP");
      output("M = M - 1");

      output("@SP");
      output("A = M");

      output("D = M");
    }

    public void pushConstant(int x) throws IOException
    {
      output("@" + x);
      output("D = A");
      pushD();
    }

    public void add() throws IOException
    {
      popD();
      output("@" + R13);
      output("M = A");
      output("M = D");
      popD();
      output("@" + R14);
      output("M = A");
      output("M = D");
      output("@" + R13);
      output("M = M + D");
      output("D = M");
      pushD();
    }

    public void sub() throws IOException
    {
      popD();
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("D = D - M");
      pushD();
    }

    public void and() throws IOException
    {
      popD();
      output("@" + R13);
      output("M = A");
      output("M = D");
      popD();
      output("@" + R13);
      output("D = D & M");
      pushD();
    }

    public void or() throws IOException
    {
      popD();
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("D = D | M");
      pushD();
    }

    public void neg() throws IOException
    {
      popD();
      output("D = -D");
      pushD();
    }

    public void not() throws IOException
    {
      popD();
      output("D = !D");
      pushD();
    }

    public void eq() throws IOException
    {
      Random random = new Random();
      int equalTrue = random.nextInt();
      int equalFalse = random.nextInt();
      int end = random.nextInt();

      popD();
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("D = D - M");
      output("@equalTrue" + equalTrue);
      output("D; JEQ");
      output("@equalFalse" + equalFalse);
      output("D; JNE");
      output("(equalTrue" + equalTrue +")");
      output("D = -1");
      output("@end" + end);
      output("0; JMP");
      output("(equalFalse" + equalFalse +")");
      output("@0");
      output("D = A");
      output("(end" + end +")");
      pushD();
    }

    public void lt() throws IOException
    {
      Random random = new Random();
      int lesst = random.nextInt();
      int notlesst = random.nextInt();
      int end = random.nextInt();

      popD();
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("D = D - M");
      output("@lesst" + lesst);
      output("D; JLT");
      output("@notlesst" + notlesst);
      output("D; JGE");
      output("(lesst" + lesst +")");
      output("D = -1");
      output("@end" + end);
      output("0; JMP");
      output("(notlesst" + notlesst +")");
      output("@0");
      output("D = A");
      output("(end" + end +")");
      pushD();
    }

    public void gt() throws IOException
    {
      Random random = new Random();
      int greatert = random.nextInt();
      int notgreatert = random.nextInt();
      int end = random.nextInt();

      popD();
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("D = D - M");
      output("@greatert" + greatert);
      output("D; JGT");
      output("@notgreatert" + notgreatert);
      output("D; JLE");
      output("(greatert" + greatert + ")");
      output("D = -1");
      output("@end" + end);
      output("0; JMP");
      output("(notgreatert" + notgreatert + ")");
      output("@0");
      output("D = A");
      output("(end" + end +")");
      pushD();
    }

    public void pushLocal(int index) throws IOException
    {
      output("@LCL");
      output("D = M");
      output("@" + index);
      output("A = D + A");
      output("D = M");
      pushD();
    }

    public void pushArgument(int index) throws IOException
    {
      output("@ARG");
      output("D = M");
      output("@" + index);
      output("A = D + A");
      output("D = M");
      pushD();
    }

    public void pushThis(int index) throws IOException
    {
      output("@THIS");
      output("D = M");
      output("@" + index);
      output("A = D + A");
      output("D = M");
      pushD();
    }

    public void pushThat(int index) throws IOException
    {
      output("@THAT");
      output("D = M");
      output("@" + index);
      output("A = D + A");
      output("D = M");
      pushD();

    }


    public void pushTemp(int index) throws IOException
    {
      output("@" + index);
      output("D = A");
      output("@5");
      output("A = D + A");
      output("D = M");
      pushD();

    }

    public void pushPointer(int index) throws IOException
    {
      output("@" + index);
      output("D = A");
      output("@PTR");
      output("A = M + D");
      output("D = M");
      pushD();
    }

    public void pushStatic(int index) throws IOException
    {
      output("@" + currentFilename + "." + index);
      output("D = M");
      pushD();
    }

    public void popLocal(int index) throws IOException
    {
      output("@LCL");
      output("D = M");
      output("@" + index);
      output("D = D + A");
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("A = M");
      output("M = D");
    }

    public void popArgument(int index) throws IOException
    {
      output("@ARG");
      output("D = M");
      output("@" + index);
      output("D = D + A");
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("A = M");
      output("M = D");

    }

    public void popThis(int index) throws IOException
    {
      output("@THIS");
      output("D = M");
      output("@" + index);
      output("D = D + A");
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("A = M");
      output("M = D");
    }

    public void popThat(int index) throws IOException
    {
      output("@THAT");
      output("D = M");
      output("@" + index);
      output("D = D + A");
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("A = M");
      output("M = D");

    }

    public void popTemp(int index) throws IOException
    {
      output("@" + index);
      output("D = A");
      output("@5");
      output("D = A + D");
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("A = M");
      output("M = D");
    }

    public void popPointer(int index) throws IOException
    {
      output("@" + index);
      output("D = A");
      output("@3");
      output("D = A + D");
      output("@" + R13);
      output("M = D");
      popD();
      output("@" + R13);
      output("A = M");
      output("M = D");


    }

    public void popStatic(int index) throws IOException
    {
      popD();
      output("@" + currentFilename + "." + index);
      output("M = A");
      output("M = D");
    }
}
